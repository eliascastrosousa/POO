
Java SE Development Kit 11.0.8 ( JDK )
	https://www.oracle.com/java/technologies/javase-jdk11-downloads.html

ECLIPSE IDE for Enterprise Java Developers
	Linux 64-bit       -    http://eclipse.c3sl.ufpr.br/technology/epp/downloads/release/2019-12/R/eclipse-jee-2019-12-R-linux-gtk-x86_64.tar.gz   
	Windows 64-bit     -    http://eclipse.c3sl.ufpr.br/technology/epp/downloads/release/2019-12/R/eclipse-jee-2019-12-R-win32-x86_64.zip
	Mac Cocoa 64-bit   -    http://espejito.fder.edu.uy/eclipse/technology/epp/downloads/release/2019-12/R/eclipse-jee-2019-12-R-macosx-cocoa-x86_64.dmg

Servidor JavaWeb - Apache Tomcat
	https://archive.apache.org/dist/tomcat/tomcat-9/v9.0.37/bin/apache-tomcat-9.0.37.zip

MySql Server
	Linux (tutorial pra montar ambiente LAMP):
		https://www.digitalocean.com/community/tutorials/how-to-install-linux-apache-mysql-php-lamp-stack-on-ubuntu-20-04-pt

	Windows:
		https://www.apachefriends.org/pt_br/index.html
		https://www.wampserver.com/
		http://zwamp.sourceforge.net/
		https://www.easyphp.org/
	
MySQL Workbench
	https://dev.mysql.com/downloads/workbench/
	
	
Bibliotecas Utilizadas
	activation.jar
	gson-2.8.6.jar
	gson-2.8.6-javadoc.jar
	mail.jar
	mysql-connector-java-5.1.34-bin.jar
	mysql-connector-java-8.0.17.jar	

Classes desenvolvidas pelo Professor Cleber e sugeridas para utilizar nos projetos	
	classes.database.DBConnection.java
	classes.database.DBQuery.java
	classes.mail.SendMail.java
	classes.multitools.Utilities.java
	classes.multitools.JsonUtilities.java


	
